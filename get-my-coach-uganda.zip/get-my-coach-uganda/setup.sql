-- ============================================================
-- Get My Coach Uganda - Database & Storage Setup
-- Run this once in the Supabase SQL Editor.
-- Safe to re-run.
-- ============================================================

-- 1. Profiles table -----------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key,
  email text unique,
  full_name text,
  role text check (role in ('student', 'coach', 'admin')) default 'student',
  phone text,
  category text,
  experience_years int default 0,
  hourly_rate int default 0,
  location text,
  bio text,
  image_url text,
  is_verified boolean default false,
  payment_status text default 'pending',  -- pending | submitted | paid
  created_at timestamptz default now()
);

-- Add columns if the table already existed
alter table public.profiles add column if not exists phone text;
alter table public.profiles add column if not exists category text;
alter table public.profiles add column if not exists experience_years int default 0;
alter table public.profiles add column if not exists hourly_rate int default 0;
alter table public.profiles add column if not exists location text;
alter table public.profiles add column if not exists bio text;
alter table public.profiles add column if not exists image_url text;
alter table public.profiles add column if not exists is_verified boolean default false;
alter table public.profiles add column if not exists payment_status text default 'pending';
alter table public.profiles add column if not exists created_at timestamptz default now();

-- For testing simplicity (Flask uses anon key directly).
-- In production switch to RLS + service role.
alter table public.profiles disable row level security;

-- Performance indexes
create index if not exists idx_profiles_role        on public.profiles (role);
create index if not exists idx_profiles_verified    on public.profiles (is_verified);
create index if not exists idx_profiles_payment     on public.profiles (payment_status);
create index if not exists idx_profiles_category    on public.profiles (category);

-- 2. Storage bucket for coach images -----------------------------------------
insert into storage.buckets (id, name, public)
values ('coach-images', 'coach-images', true)
on conflict (id) do update set public = true;

-- Allow public read + anon upload (testing setup)
do $$
begin
  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage' and tablename = 'objects'
      and policyname = 'coach_images_public_read'
  ) then
    create policy coach_images_public_read on storage.objects
      for select using (bucket_id = 'coach-images');
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage' and tablename = 'objects'
      and policyname = 'coach_images_anon_upload'
  ) then
    create policy coach_images_anon_upload on storage.objects
      for insert with check (bucket_id = 'coach-images');
  end if;

  if not exists (
    select 1 from pg_policies
    where schemaname = 'storage' and tablename = 'objects'
      and policyname = 'coach_images_anon_update'
  ) then
    create policy coach_images_anon_update on storage.objects
      for update using (bucket_id = 'coach-images');
  end if;
end $$;
